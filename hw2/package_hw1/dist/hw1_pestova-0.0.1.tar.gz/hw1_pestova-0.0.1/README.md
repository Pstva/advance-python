# Homework 1

**Easy**: [функция Фибоначчи](fib.py)

**Medium+Hard**: [построение графа AST](AST.py)

